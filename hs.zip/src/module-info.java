/**
 * 
 */
/**
 * 
 */
module HospitalManagmentSystem {
	requires java.sql;
}